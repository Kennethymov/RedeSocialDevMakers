import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Perfil {
    String nome;
    String login;
    String senha;
    List<Post> posts = new ArrayList<Post>();
    Scanner sc = new Scanner(System.in);


}
