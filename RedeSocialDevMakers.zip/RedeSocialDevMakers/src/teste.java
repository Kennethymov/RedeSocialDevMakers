import java.util.Scanner;

public class teste {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String nome;
        nome = sc.nextLine();
        System.out.println(nome);
    }
}
