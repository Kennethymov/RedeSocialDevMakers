public class Post {
    String data;
    String hora;
    String text;
}
